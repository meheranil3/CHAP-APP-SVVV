package com.leschat.chats.utility;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.leschat.chats.R;
import com.leschat.chats.chat.ChatlistAdaptor;
import com.leschat.chats.chat.Chatobject;

import java.util.ArrayList;

import static android.Manifest.permission.READ_CONTACTS;
import static android.Manifest.permission.WRITE_CONTACTS;

public class FrontPage extends AppCompatActivity {

    private RecyclerView mchatlist;
    private RecyclerView.Adapter mchatlistAdaptor;
    private RecyclerView.LayoutManager mchatListLayoutManager;

    ArrayList<Chatobject> chatlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_front_page);

        Button b = (Button) findViewById(R.id.SignOut);             //logout button
        Button finduser = (Button) findViewById(R.id.findUsers);    //find-users button


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut(); // user now logged out
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class); // redirects to the login page
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // to clear the previous login activity (if any was running is stopped)
                startActivity(intent);
                finish();
                return;
            }
        });

        //FIND - USER BUTTON --
        finduser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), FinduserActivity.class)); // redirects to FinduserActivity page
            }
        });
        getPermissions();
        initializeRecyclerview();
        getUserchatlist();
    }

    private void getUserchatlist() {
        DatabaseReference mUserChatDB = FirebaseDatabase.getInstance().getReference().child("user").child(FirebaseAuth.getInstance().getUid()).child("chat");
        mUserChatDB.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                        Chatobject mChat = new Chatobject(childSnapshot.getKey());
                        boolean exists = false;
                        for (Chatobject miter : chatlist) {
                            if (miter.getChatId().equals(mChat.getChatId())) {
                                exists = true;
                            }
                        }
                        if (exists)
                            continue;
                        chatlist.add(mChat);
                        mchatlistAdaptor.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void initializeRecyclerview() {
        mchatlist = (RecyclerView) findViewById(R.id.chatlist);
        mchatlist.setNestedScrollingEnabled(false);
        mchatlist.setHasFixedSize(false);
        mchatListLayoutManager = new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false);
        mchatlist.setLayoutManager(mchatListLayoutManager);
        mchatlistAdaptor = new ChatlistAdaptor(chatlist);
        mchatlist.setAdapter(mchatlistAdaptor);
    }

    private void getPermissions() {     // getting user perms for accessing his contacts

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{WRITE_CONTACTS, READ_CONTACTS}, 1);
        }

    }
}
