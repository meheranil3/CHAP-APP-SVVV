package com.leschat.chats;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.leschat.chats.R;
import com.leschat.chats.MessageObject;

import java.util.ArrayList;
// the RecyclerView adapter class --
public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageAdapterViewHolder> {

    ArrayList<MessageObject> messageList;
    public MessageAdapter(ArrayList<MessageObject> userList) {
        this.messageList = messageList;
    }


    @NonNull
    @Override
    public MessageAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View LayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message,null,false);  //inflate the item_user in our recyclerview
        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        LayoutView.setLayoutParams(lp);
        MessageAdapterViewHolder rcv  = new MessageAdapterViewHolder(LayoutView);

        return rcv;
    }


    @Override
    public void onBindViewHolder(@NonNull MessageAdapterViewHolder holder, final int position) {
        holder.mMessage.setText(messageList.get(position).getmessageId());
        holder.mSender.setText(messageList.get(position).getSenderId());
    }


    @Override
    public int getItemCount() {
        return messageList.size();
    }


    public class MessageAdapterViewHolder extends RecyclerView.ViewHolder {
        public TextView mSender, mMessage;
        public LinearLayout mlayout;
        public MessageAdapterViewHolder (View view) {
            super(view);

            mlayout = view.findViewById(R.id.display);
            mSender = view.findViewById(R.id.sender);
            mMessage = view.findViewById(R.id.messageList);
        }
    }
}

