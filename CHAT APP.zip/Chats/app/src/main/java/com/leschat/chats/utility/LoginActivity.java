package com.leschat.chats.utility;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.leschat.chats.R;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class LoginActivity extends AppCompatActivity {

    private EditText motp,mPhoneNumbner;
    private Button msend;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mcallbacks;
    String verificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseApp.initializeApp(this);

        UserIsloggedIn(); //checking if the user is already logged in then no need for the rest

        mPhoneNumbner = (EditText) findViewById(R.id.phoneNumber);
        motp = (EditText) findViewById(R.id.otp);
        msend = (Button) findViewById(R.id.send);

        msend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (verificationId != null)
                    verifyPhoneNummberwithOTP();
                else
                    startPhonenoVerification();
             }
            }
        );
      
        mcallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
            signInwithPhoneAuth(phoneAuthCredential);
            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) { }

            @Override
            /* method called whenever otp is sent to the user -- */
            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(s, forceResendingToken);
                verificationId = s;
                msend.setText("verify OTP");
            }
        };


    }

    private void verifyPhoneNummberwithOTP () {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId,motp.getText().toString());
        signInwithPhoneAuth(credential);
    }

    private void signInwithPhoneAuth(PhoneAuthCredential phoneAuthCredential) {
        FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if (user!= null) {
                    final DatabaseReference mUserDB = FirebaseDatabase.getInstance().getReference().child("user").child(user.getUid());  //points to a user id in the database
                    mUserDB.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (!dataSnapshot.exists()) {
                                Map<String , Object> UserMap = new HashMap<>();
                                UserMap.put("phone", user.getPhoneNumber());
                                UserMap.put("name", user.getDisplayName());
                                mUserDB.updateChildren(UserMap);
                            }
                            UserIsloggedIn();   // method for redirecting the user to front page
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                    }
                }
            }
        });
    }

    private void UserIsloggedIn() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            startActivity(new Intent(getApplicationContext(),FrontPage.class));
            finish();
            return;
        }
    }

    private void startPhonenoVerification() {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(mPhoneNumbner.getText().toString(),60,
                TimeUnit.SECONDS,this,mcallbacks);
        }
}
