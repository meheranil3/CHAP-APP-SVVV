package com.leschat.chats.chat;

public class Chatobject {
    public String chatId;

    public Chatobject (String chatId) {
        this.chatId = chatId;
    }

    public String getChatId () { return chatId; }
}
