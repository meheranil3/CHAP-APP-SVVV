package com.leschat.chats.user;

public class UserObject {
    private String name,Phone,Uid;

    public UserObject(String Uid, String name, String Phone) {
        this.name = name;
        this.Uid = Uid;
        this.Phone = Phone;
    }
        public String getName() {return name;}
        public String getPhone() {return Phone;}
        public String getUid() {return Uid;}

        public void setName(String name) {this.name = name;}
}
