package com.leschat.chats.user;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.leschat.chats.R;

import java.util.ArrayList;
    // the RecyclerView adapter class --
public class UserListAdapter extends RecyclerView.Adapter<UserListAdapter.UserListViewHolder> {

    ArrayList<UserObject> userList;
    public UserListAdapter (ArrayList<UserObject> userList) {
        this.userList = userList;
    }


    @NonNull
    @Override
    public UserListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View LayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_holder,null,false);  //inflate the item_user in our recyclerview
        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        LayoutView.setLayoutParams(lp);
        UserListViewHolder rcv  = new UserListViewHolder(LayoutView);

        return rcv;
    }


    @Override
    public void onBindViewHolder(@NonNull UserListViewHolder holder, final int position) {
    holder.mname.setText(userList.get(position).getName());
    holder.mphone.setText(userList.get(position).getPhone());
    holder.mlayout.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String key = FirebaseDatabase.getInstance().getReference().child("chat").push().getKey();
            FirebaseDatabase.getInstance().getReference().child("user").child(FirebaseAuth.getInstance().getUid()).child("chat").child(key).setValue(true);
            FirebaseDatabase.getInstance().getReference().child("user").child(userList.get(position).getUid()).child("chat").child(key).setValue(true);

        }
    });
    }


    @Override
    public int getItemCount() {
        return userList.size();
    }


    public class UserListViewHolder extends RecyclerView.ViewHolder {
        public TextView mname,mphone; // our textviews in item-holder.xml
        public ConstraintLayout mlayout;
        public UserListViewHolder (View view) {
            super(view);
            mname = view.findViewById(R.id.name);
            mphone = view.findViewById(R.id.phone);
            mlayout = view.findViewById(R.id.display);

        }
    }
}

