package com.leschat.chats.utility;

import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.leschat.chats.R;
import com.leschat.chats.user.UserListAdapter;
import com.leschat.chats.user.UserObject;

import java.util.ArrayList;

public class FinduserActivity extends AppCompatActivity {

    private RecyclerView muserlist;
    private RecyclerView.Adapter muserlistAdaptor;
    private RecyclerView.LayoutManager muserListLayoutManager;

    ArrayList<UserObject> userlist, contactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finduser);
        userlist = new ArrayList<>();
        contactList = new ArrayList<>();

        initializeRecyclerview();
        getContactsList();

    }

    private void getContactsList () {  //basically fetching contacts from the contacts application
        String ISOprefix = getCountryISO();
        Cursor phones = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,null,null);
        }

        while (phones.moveToNext()) {  // and iterating over the contacts
            String name = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String phone = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

           //normalizing contacts --
            phone = phone.replace(" ","");
            phone = phone.replace("-","");
            phone = phone.replace("(","");
            phone = phone.replace(")","");

            if (!String.valueOf(phone.charAt(0)).equals("+"))
                phone = ISOprefix + phone;

            UserObject mcontact = new UserObject("",name,phone);   // creating a userobject which has name and phone number
            contactList.add(mcontact);     // adding this contact to the arraylist of contact objects

            getuserDetails(mcontact);
        }

    }

    private void getuserDetails(UserObject mcontact) {
        DatabaseReference mUserDB = FirebaseDatabase.getInstance().getReference().child("user");
        Query query = mUserDB.orderByChild("phone").equalTo(mcontact.getPhone());
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String phone = "",
                            name = "";
                     for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                         if (childSnapshot.child("phone").getValue().toString() != null)
                            phone = childSnapshot.child("phone").getValue().toString();
                         if (childSnapshot.child("name").getValue().toString() != null)
                             name = childSnapshot.child("name").getValue().toString();

                         UserObject mUser = new UserObject(childSnapshot.getKey(),name,phone);
                         if (name.equals(phone))
                             for (UserObject mUserobjiter : contactList) {
                                 if (mUserobjiter.getPhone().equals(mUser.getPhone())) {
                                     mUser.setName(mUserobjiter.getName());
                                 }
                             }


                        userlist.add(mUser);
                        muserlistAdaptor.notifyDataSetChanged();   // new contact added so updating the recyclerview adapter
                        return;
                     }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private String getCountryISO() {
        String iso= null;
        TelephonyManager telephonyManager = (TelephonyManager) getApplicationContext().getSystemService(getApplicationContext().TELEPHONY_SERVICE);
        if (!telephonyManager.getNetworkCountryIso().toString().equals(""))
            iso = telephonyManager.getNetworkCountryIso().toString();
        return CountryToPrefix.getPhone(iso);
    }

    private void initializeRecyclerview() {
        muserlist = (RecyclerView) findViewById(R.id.userlist);
        muserlist.setNestedScrollingEnabled(false);
        muserlist.setHasFixedSize(false);
        muserListLayoutManager = new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL ,false);
        muserlist.setLayoutManager(muserListLayoutManager);
        muserlistAdaptor = new UserListAdapter(userlist);
        muserlist.setAdapter(muserlistAdaptor);
    }
}
