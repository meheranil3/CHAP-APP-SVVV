package com.leschat.chats;

public class MessageObject {
    public String messageId, senderId, text;

    public MessageObject (String messageId,String SenderId,String text) {
        this.messageId = messageId;
        this.senderId = SenderId;
        this.text = text;
    }

    public String getmessageId () { return messageId; }
    public String getSenderId () { return senderId; }
    public String getText () { return text; }
}
